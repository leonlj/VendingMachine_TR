﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.Devices;
using Microsoft.Azure.Devices.Common.Exceptions;

namespace ConsoleApplication1
{
    //First install Azure.Devices nuget package
    class Program
    {
        static RegistryManager registryManager;
        static string connectionString = "HostName=OWVendorMachinehub.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=lWUnojZ30JdxA7I9Jame6filsPwZph8PPFdf9ICpiuk=";
        static void Main(string[] args)
        {
            registryManager = RegistryManager.CreateFromConnectionString(connectionString);
            AddDeviceAsync().Wait();
            Console.ReadLine();
        }

        private async static Task AddDeviceAsync()
        {
            string deviceId = "myDevice1";
            Device device = null ;
            bool deviceexsits = false;
            try
            {
                device = await registryManager.AddDeviceAsync(new Device(deviceId));
                deviceexsits = true;
            }
            catch (DeviceAlreadyExistsException)
            {
                deviceexsits = false; 
            }

            if (deviceexsits == false)
            {
                device = await registryManager.GetDeviceAsync(deviceId);
            }
            Console.WriteLine("Generated device key: {0}", device.Authentication.SymmetricKey.PrimaryKey);
        }
    }
}
